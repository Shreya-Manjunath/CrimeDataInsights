import matplotlib.pyplot as plt
import pymysql
import mysql.connector
import seaborn as sns

connection=mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="Shreya@2001",
    database="project"
)
cursor = connection.cursor()
query = "SELECT Location FROM project.crime_data"
cursor.execute(query)
results = cursor.fetchall()
cursor.close()
connection.close()

# Extract locations for analysis
locations = [result[0] for result in results if result[0] is not None]

# Count occurrences of each location
location_counts = {}
for location in locations:
    location_counts[location] = location_counts.get(location, 0) + 1

# Sort locations by crime occurrence in descending order
sorted_locations = sorted(location_counts.items(), key=lambda x: x[1], reverse=True)

# Plotting the top locations with the highest crime occurrence
top_locations = sorted_locations[:10]  # Adjust the number based on your preference
labels, counts = zip(*top_locations)

plt.figure(figsize=(15, 6))
plt.bar(labels, counts, color='salmon')
plt.title('Top Locations with the Highest Crime Occurrence')
plt.xlabel('Location')
plt.ylabel('Number of Incidents')
plt.xticks(rotation=10, ha='right')  # Rotate x-axis labels for better visibility
plt.show()
