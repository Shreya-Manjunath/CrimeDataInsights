import matplotlib.pyplot as plt
import pymysql
import mysql.connector
import seaborn as sns

connection=mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="Shreya@2001",
    database="project"
)
cursor = connection.cursor()
query = "SELECT Crm_Cd, Crm_Cd_Desc FROM project.crime_data;"
cursor.execute(query)
results = cursor.fetchall()
cursor.close()
connection.close()

# Extract crime codes and descriptions for analysis
crime_codes = [result[0] for result in results if result[0] is not None]
crime_descriptions = [result[1] for result in results if result[1] is not None]

# Count occurrences of each crime code
crime_code_counts = {}
for crime_code in crime_codes:
    crime_code_counts[crime_code] = crime_code_counts.get(crime_code, 0) + 1

# Sort crime codes by occurrence in descending order
sorted_crime_codes = sorted(crime_code_counts.items(), key=lambda x: x[1], reverse=True)

# Plotting the distribution of reported crimes based on Crime Code
top_crime_codes = sorted_crime_codes[:50]
labels, counts = zip(*top_crime_codes)

plt.figure(figsize=(12, 6))
plt.bar(labels, counts, color='skyblue')
plt.title('Distribution of Reported Crimes Based on Crime Code')
plt.xlabel('Crime Code')
plt.ylabel('Number of Incidents')
plt.xticks(rotation=45, ha='right')
plt.show()
