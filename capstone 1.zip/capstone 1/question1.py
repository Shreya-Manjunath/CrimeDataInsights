import matplotlib.pyplot as plt
import pymysql
import mysql.connector
import seaborn as sns

connection=mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="Shreya@2001",
    database="project"
)
cursor = connection.cursor()

# SQL query to retrieve Latitude, Longitude, area_name and crime code description
query = "SELECT lat, lon, Area_Name, Crm_Cd_Desc FROM project.crime_data;"

cursor.execute(query)
results = cursor.fetchall()

# Close the cursor and connection
cursor.close()
connection.close()

# Extracting Latitude and Longitude for plotting
latitude = [result[0] for result in results]
longitude = [result[1] for result in results]
area_names = [result[2] for result in results]
crime_descriptions = [result[3] for result in results]

# Creating a scatter plot
plt.figure(figsize=(10, 8))
plt.scatter(longitude, latitude, alpha=0.5, c='red', edgecolors='none', s=20)

# Adding labels and title
plt.title('Geographical Hotspots for Reported Crimes')
plt.xlabel('Longitude')
plt.ylabel('Latitude')

# Shows area names and crime descriptions
for i, area_name in enumerate(area_names):
    plt.annotate(f'{area_name}\n{crime_descriptions[i]}', (longitude[i], latitude[i]), alpha=0.7)

# Shows the plot
plt.show()
