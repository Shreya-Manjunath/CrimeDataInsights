import mysql.connector
import seaborn as sns
import matplotlib.pyplot as plt
import pymysql

connection=mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="Shreya@2001",
    database="project"
)

cursor = connection.cursor()

# Query to retrieve victim age and sex
query = "SELECT Vict_Age, Vict_Sex FROM project.crime_data"

cursor.execute(query)
results = cursor.fetchall()
cursor.close()
connection.close()

# Extract victim age and sex for analysis
victim_ages = [result[0] for result in results if result[0] is not None]
victim_sexes = [result[1] for result in results if result[1] is not None]

# Plotting the distribution of victim ages
plt.figure(figsize=(12, 6))
plt.hist(victim_ages, bins=20, color='skyblue', edgecolor='black')
plt.title('Distribution of Victim Ages in Reported Crimes')
plt.xlabel('Victim Age')
plt.ylabel('Number of Incidents')
plt.grid(True)
plt.show()

# Plotting the comparison of crime rates between male and female victims
plt.figure(figsize=(8, 5))
sex_counts = [victim_sexes.count('M'), victim_sexes.count('F')]
sex_labels = ['Male', 'Female']
plt.bar(sex_labels, sex_counts, color=['lightblue', 'lightcoral'])
plt.title('Comparison of Crime Rates between Male and Female Victims')
plt.xlabel('Victim Sex')
plt.ylabel('Number of Incidents')
plt.show()
